Congratulations! You got yourself a Car Insurance Policy for your CHEVROLET CRUZE LT at 5/20, GROUND FLOOR NEW DOUBLE STOREY LAJPAT NAGAR-IV, DELHI NORTH EAST 110025 DELHI. Your policy number is **9302735312004378**.

We want to make sure you know what you're getting for your **Rs 4,000.07 per year**, so we did our best to make this policy short and sweet.

Please take a few minutes to read through, and let us know if you have any questions. You can always change coverages, and more.

## Who's covered?
This policy covers **MR. KARAN SHARMA and the CHEVROLET CRUZE LT**.

## When?
This policy covers events that started after 00:00 Hrs on 07/08/2014, and before 23:59 Hrs on 06/08/2015.

## Against what?
We protect you against any damage to your vehicle, excluding hire or reward, carriage of goods other than samples or personal luggage, organized racing, pace making, speed testing, reliability trials, and any purpose in connection with Motor Trade. There are important limitations, though, so please read on.

## For how much?
We provide coverage up to a certain limit. Here is a quick overview of the limits you chose (and can change):

- Damage to property other than property belonging to the insured or held in trust or in the custody of control of the insured up to the limits specified Rs.7.5 lakhs.
- Compulsory deductible Rs. 1000/-
- Additional compulsory deductible Rs. 0/-
- Voluntary deductible Rs. 0 /-
- PA Cover for owner-driver under section III CSI Rs. 200000/-

These amounts indicate the maximum we will reimburse you, in total, per year - even if the losses you suffer are larger.

So take a minute to check your policy and see if these limits are enough to cover your vehicle and any potential accidents.

If Rs. 7.5 lakhs isn't enough to cover everything, please increase your total coverage.

## Used or new?
This policy covers the Insured's Declared Value of Rs 250,485.00 for your vehicle. This amount is the maximum we will pay out for a claim, reflecting the current market value of your car.