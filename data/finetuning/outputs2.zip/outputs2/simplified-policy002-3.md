Congratulations! You got yourself a Private Car Vehicle Insurance Policy for your HYUNDAI i10 at 9/25, GROUND FLOOR OLD DOUBLE STOREY LAJPAT NAGAR-IV DELHI NORTH WEST 110024 DELHI. Your policy number is **9202732311005278**.

We want to make sure you know what you're getting for your **Rs. 4,482.00 per year**, so we did our best to make this policy short and sweet.

Please take a few minutes to read through, and let us know if you have any questions. You can always change coverages, add valuable items, and more.

## Who's covered?
This policy covers **MR. AKASH GUPTA and anyone with an effective driving license at the time of the accident**.

## When?
This policy covers events that started after 00:00 Hrs on 06/08/2014, and before 05/08/2015 on 23:59.

## Against what?
We protect you against any damage to the car and bodily injury to any person, except for certain conditions like organized racing, speed testing and reliability trials. There are important limitations, though, so please read on.

## For how much?
We provide coverage up to a certain limit. Here is a quick overview of the limits you chose (and can change):

- Death or bodily injury: As per the requirements of the Motor Vehicle Act, 1988.
- Damage to property other than belonging to the insured: Up to Rs.7.5 lakhs.

These amounts indicate the maximum we will reimburse you, in total, per year - even if the losses you suffer are larger.

So take a minute to check your policy considering the value of your vehicle and the potential cost of damages.

If Rs.250,485.00 isn't enough to cover everything, please increase your total coverage.

## Used or new?
If your car is damaged beyond repair, we will pay you the Insured's Declared Value of Rs.250,485.00, which is the market value of your car minus depreciation.