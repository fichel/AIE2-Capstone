Congratulations! You got yourself a Private Car Vehicle Policy for your Hyundai i10 Magna at 3/28, FIRST FLOOR NEW SINGLE STOREY KALKAJI NEW DELHI SOUTH EAST 110019 DELHI. Your policy number is **9202732311007432**.

We want to make sure you know what you're getting for your **Rs. 4,602.00 per annum**, so we did our best to make this policy short and sweet.

Please take a few minutes to read through, and let us know if you have any questions. You can always change coverages, and more.

## Who's covered?
This policy covers **MR. PRANAV MUKHERJEE and any person including the insured provided that a person driving holds an effective driving license at the time of the accident and is not disqualified from holding or obtaining such a license**.

## When?
This policy covers events that started after 07/09/2013, and before 06/09/2014.

## Against what?
We protect you against any damages and accidents. There are important limitations, though, so please read on.

## For how much?
We provide coverage up to a certain limit. Here is a quick overview of the limits you chose (and can change):

- Insured's Declared Value (IDV): Rs. 267,385.00
- Damage to property: up to Rs. 7.5 lakhs
- Compulsory deductible: Rs. 1000
- Personal Accident Cover (PA) for owner-driver: Rs. 200,000

These amounts indicate the maximum we will reimburse you, in total, per year - even if the losses you suffer are larger.

So take a minute to check your policy. If the insured's declared value isn't enough to cover the cost of your vehicle, please increase your total coverage. 

## Used or new?
The policy covers the used car and it has been issued based on the information provided by you. In the event of a claim, please call along with your Policy No.on 1800 103 1999 (toll free) or 022 41112600 (Standard STD Rates Apply) and register your claim immediately within 7 days from the date of loss. For Customer service, Please call along with your Policy No. on 1800 300 28282(toll free) or 39898282 (local charges apply).