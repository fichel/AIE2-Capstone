Congratulations! You got yourself a Private Car Vehicle Policy for your CHEVROLET SPARK LT at 4/19, GROUND FLOOR OLD DOUBLE STOREY LAJPAT NAGAR-IV DELHI NORTH WEST 110024 DELHI. Your policy number is **9202732311004278**.

We want to make sure you know what you're getting for your **Rs 4,382 per year**, so we did our best to make this policy short and sweet.

Please take a few minutes to read through, and let us know if you have any questions. You can always change coverages, and more.

## Who's covered?
This policy covers **MR. ARUNAV TALUKDAR and his CHEVROLET SPARK LT**.

## When?
This policy covers events that started after 06/08/2013, and before 05/08/2014.

## Against what?
We protect you against any purpose other than: a. Hire or Reward, b. Carriage of goods (other than samples or personal luggage), c. Organized racing, d. Pace making, e. Speed testing, f. Reliability trials, g. Any purpose in connection with Motor Trade. There are important limitations, though, so please read on.

## For how much?
We provide coverage up to a certain limit. Here is a quick overview of the limits you chose (and can change):

- Insured's Declared Value: Rs 237,485
- Damage to property other than property belonging to the insured: up to Rs.7.5 lakhs

These amounts indicate the maximum we will reimburse you, in total, per year - even if the losses you suffer are larger.

So take a minute to check your policy if Rs 237,485 isn't enough to cover everything, please increase your total coverage.

## Used or new?
This policy provides a "Basic Own Damage Premium" coverage which is the cost to replace your vehicle with a new one of similar kind and quality up to the declared value of Rs 237,485.
