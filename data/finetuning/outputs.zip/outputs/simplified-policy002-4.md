Congratulations! You got yourself a Private Car Vehicle Policy for your Hyundai i10 MAGNA at 3/28, FIRST FLOOR NEW SINGLE STOREY KALKAJI NEW DELHI SOUTH EAST 110019 DELHI. Your policy number is 9202732311007432.

We want to make sure you know what you're getting for your Rs. 4,602.00 per year, so we did our best to make this policy short and sweet.

Please take a few minutes to read through, and let us know if you have any questions. You can always change coverages, add valuable items, and more.

Who's covered?
This policy covers MR. PRANAV MUKHERJEE and any person entitled to drive the vehicle.

When?
This policy covers events that started after 00:00 Hrs on 07/09/2013, and before 06/09/2014 on 23:59.

Against what?
We protect you against death or bodily injury to any person and damage to property up to the specified limits.

For how much?
We provide coverage up to a certain limit. Here is a quick overview of the limits you chose (and can change):

- Death or bodily injury to any person: As required by the Motor Vehicle Act, 1988
- Damage to property: Up to Rs. 7.5 lakhs

These amounts indicate the maximum we will reimburse you, in total, per year - even if the losses you suffer are larger.

So take a minute to check your policy and consider if the coverage limits are adequate.

If the coverage isn't enough to cover everything, please increase your total coverage. 

Used or new?
The policy covers damages occurring after the commencement of cover, excluding pre-existing damages.