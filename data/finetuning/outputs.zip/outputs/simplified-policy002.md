Congratulations! You got yourself a Private Car Package Policy for your Vehicle at 4/19, GROUND FLOOR OLD DOUBLE STOREY LAJPAT NAGAR-IV DELHI NORTH WEST 110024 DELHI. Your policy number is 9202732311004278.

We want to make sure you know what you're getting for your Rs 4,382 per year, so we did our best to make this policy short and sweet.

Please take a few minutes to read through, and let us know if you have any questions. You can always change coverages, add valuable items, and more.

Who's covered?
This policy covers MR. ARUNAV TALUKDAR.

When?
This policy covers events that started after 00:00 Hrs on 06/08/2013, and before 05/08/2014 on 23:59.

Against what?
We protect you against Fire, Self Ignition, Explosion, Lightning, Theft, Burglary, Housebreaking, Riot, Strike, Earthquake, Flood and allied perils, Accidental external means, Malicious acts, Terrorist activity, Transit, Landslide / rockslide. There are important limitations, though, so please read on.

For how much?
We provide coverage up to a certain limit. Here is a quick overview of the limits you chose (and can change):

- Under Section II-1(i) of the Policy-Death of or bodily injury to any person so far as it is necessary to meet the requirements of the Motor Vehicle Act, 1988.
- Under Section II (1)(ii) of the Policy-Damage to property other than property belonging to the insured or held in trust or in the custody of control of the insured up to the limits specified Rs.7.5 lakhs.

These amounts indicate the maximum we will reimburse you, in total, per year - even if the losses you suffer are larger.

So take a minute to check your policy and consider if the coverage limits are adequate.

If the coverage isn't enough to cover everything, please increase your total coverage. And if you own any valuable items worth more than the coverage limit, be sure to add them to your policy so they're covered for their full amount.