Congratulations! You got yourself a Private Car Vehicle Policy for your HONDA CITY ZX at 5/24, FIRST FLOOR NEW DOUBLE STOREY LAJPAT NAGAR-IV BANGALORE SOUTH 560041 KARNATAKA. Your policy number is 9402842422005299.

We want to make sure you know what you're getting for your Rs. 5,168.00 per year, so we did our best to make this policy short and sweet.

Please take a few minutes to read through, and let us know if you have any questions. You can always change coverages, add valuable items, and more.

Who's covered?
This policy covers MR. RAVI KUMAR and any other person including the Insured provided that a person driving holds an effective driving license at the time of the accident and is not disqualified from holding or obtaining such a license.

When?
This policy covers events that started from 00:00 Hrs on 07/09/2014 and ends on 06/09/2015 at 23:59.

Against what?
We protect you against Death of or bodily injury to any person and Damage to property other than property belonging to the insured or held in trust or in the custody of control of the insured.

For how much?
We provide coverage up to a certain limit. Here is a quick overview of the limits you chose (and can change):

- Under Section II-1(i) of the Policy-Death of or bodily injury to any person up to the requirements of the Motor Vehicle Act, 1988.
- Under Section II (1)(ii) of the Policy-Damage to property up to Rs. 7.5 lakhs.

These amounts indicate the maximum we will reimburse you, in total, per year - even if the losses you suffer are larger.

So take a minute to check your policy coverage limits and make sure they are adequate for your needs.

If Rs. 357,685.00 isn't enough to cover everything, please increase your total coverage. And if you own any valuable items worth more than Rs. 357,685.00, be sure to add them to your policy so they're covered for their full amount.

Used or new?
The policy covers use for any purpose other than: a. Hire or Reward, b. Carriage of goods (other than samples or personal luggage), c. Organized racing, d. Pace making, e. Speed testing, f. Reliability trials, g. Any purpose in connection with Motor Trade.