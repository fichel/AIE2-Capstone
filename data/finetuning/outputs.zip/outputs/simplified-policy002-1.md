Congratulations! You got yourself a Private Car Vehicle Policy for your Chevrolet Spark LX at 5/20, FIRST FLOOR OLD DOUBLE STOREY LAJPAT NAGAR-IV DELHI NORTH WEST 110025 DELHI. Your policy number is 9202733451004279.

We want to make sure you know what you're getting for your Rs. 4,494.00 per year, so we did our best to make this policy short and sweet.

Please take a few minutes to read through, and let us know if you have any questions. You can always change coverages, add valuable items, and more.

Who's covered?
This policy covers MR. AKASH VERMA and any person entitled to drive the vehicle.

When?
This policy covers events that started after 00:00 Hrs on 07/08/2013, and before 06/08/2014 on 23:59.

Against what?
We protect you against death or bodily injury to any person and damage to property up to the limits specified.

For how much?
We provide coverage up to a certain limit. Here is a quick overview of the limits you chose (and can change):

- Under Section II-1(i) of the Policy: Death of or bodily injury to any person up to the requirements of the Motor Vehicle Act, 1988.
- Under Section II (1)(ii) of the Policy: Damage to property up to Rs. 7.5 lakhs.

These amounts indicate the maximum we will reimburse you, in total, per year - even if the losses you suffer are larger.

So take a minute to check your policy and consider if the coverage limits are adequate.

If Rs. 245,485.00 isn't enough to cover everything, please increase your total coverage. And if you own any valuable items worth more than the coverage limit, be sure to add them to your policy so they're covered for their full amount.

Used or new?
The policy covers damages occurring after the commencement of cover, excluding pre-existing damages.