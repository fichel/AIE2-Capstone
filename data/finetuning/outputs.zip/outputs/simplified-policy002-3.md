Congratulations! You got yourself a Private Car Vehicle Policy for your Hyundai i10 at 9/25, GROUND FLOOR OLD DOUBLE STOREY LAJPAT NAGAR-IV DELHI NORTH WEST 110024 DELHI. Your policy number is 9202732311005278.

We want to make sure you know what you're getting for your Rs. 4,482.00 per year, so we did our best to make this policy short and sweet.

Please take a few minutes to read through, and let us know if you have any questions. You can always change coverages, add valuable items, and more.

Who's covered?
This policy covers MR. AKASH GUPTA and any person entitled to drive the vehicle.

When?
This policy covers events that started after 00:00 Hrs on 06/08/2014, and before 05/08/2015 on 23:59.

Against what?
We protect you against death or bodily injury to any person and damage to property up to the limits specified.

For how much?
We provide coverage up to a certain limit. Here is a quick overview of the limits you chose (and can change):

- Death or bodily injury to any person: As necessary to meet the requirements of the Motor Vehicle Act, 1988
- Damage to property: Up to Rs. 7.5 lakhs

These amounts indicate the maximum we will reimburse you, in total, per year - even if the losses you suffer are larger.

So take a minute to check your policy and consider if the coverage limits are adequate.

If Rs. 250,485.00 isn't enough to cover everything, please increase your total coverage. And if you own any valuable items worth more than the coverage limit, be sure to add them to your policy so they're covered for their full amount.

Used or new?
The policy covers use for any purpose other than specific exclusions mentioned in the policy.